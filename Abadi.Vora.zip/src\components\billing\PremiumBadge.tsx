"use client";

import { useTranslations } from "@/i18n/use-translations";

interface PremiumBadgeProps {
  size?: "sm" | "md";
  className?: string;
}

export function PremiumBadge({ size = "sm", className = "" }: PremiumBadgeProps) {
  const { t } = useTranslations();
  const sizeClasses = size === "sm" ? "px-2 py-0.5 text-[10px]" : "px-3 py-1 text-xs";

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 font-bold uppercase tracking-wide text-white ${sizeClasses} ${className}`}
    >
      <svg className="h-3 w-3" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
      </svg>
      {t("billing.premiumBadge")}
    </span>
  );
}
